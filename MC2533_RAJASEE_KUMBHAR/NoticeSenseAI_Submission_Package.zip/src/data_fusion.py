"""
=============================================================================
Module: src/data_fusion.py
Project: NoticeSenseAI
Description: Data fusion pipeline integrating the Original Academic Notices
             dataset with the multi-API external dataset via validated Left Join.
=============================================================================
"""

import os
import sys
sys.path.insert(0, os.path.abspath("."))

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any
from src.data_cleaning import DataCleaner


class DataFusionEngine:
    """
    Performs deterministic and validated multi-source fusion between
    the internal notices dataset and external REST API features.
    """

    def __init__(self):
        self.cleaner = DataCleaner()

    def fuse_datasets(
        self,
        original_csv_path: str = "data/original_dataset.csv",
        api_csv_path: str = "data/api_dataset.csv"
    ) -> Tuple[pd.DataFrame, Dict[str, Any], pd.DataFrame]:
        """
        Loads original and API datasets, validates keys, performs Left Join,
        and generates fusion metrics and comparison summary.
        """
        if not os.path.exists(original_csv_path) or not os.path.exists(api_csv_path):
            raise FileNotFoundError("Both original_dataset.csv and api_dataset.csv must exist in data/ directory.")

        df_orig = pd.read_csv(original_csv_path)
        df_api = pd.read_csv(api_csv_path)

        # Pre-fusion cleaning
        df_orig = self.cleaner.clean_original_dataset(df_orig)
        df_api = self.cleaner.clean_api_dataset(df_api)

        # ---------------------------------------------------------------------
        # 1. Identify Common Attributes & Key Alignment
        # ---------------------------------------------------------------------
        # Primary Entity Key: Institution_Name
        # Temporal Key: Deadline_Date (Original) <-> Date (API)
        # ---------------------------------------------------------------------
        
        # Check matching keys
        orig_pairs = set(zip(df_orig["Institution_Name"], df_orig["Deadline_Date"]))
        api_pairs = set(zip(df_api["Institution_Name"], df_api["Date"]))
        
        matching_pairs = orig_pairs.intersection(api_pairs)
        unmatched_orig = orig_pairs - api_pairs

        # ---------------------------------------------------------------------
        # 2. Perform Fusion (Left Join)
        # ---------------------------------------------------------------------
        # Drop redundant columns from right dataset to avoid collision
        api_cols_to_merge = [c for c in df_api.columns if c not in ["Date", "Institution_Name"]]
        
        df_fused = pd.merge(
            df_orig,
            df_api,
            left_on=["Institution_Name", "Deadline_Date"],
            right_on=["Institution_Name", "Date"],
            how="left",
            suffixes=("", "_api")
        )

        # If any rows had missing API match (e.g. date mismatch), forward fill from same institution
        inst_api_medians = df_api.groupby("Institution_Name").first().reset_index()
        for col in api_cols_to_merge:
            if col in df_fused.columns and df_fused[col].isnull().any():
                mapping = dict(zip(inst_api_medians["Institution_Name"], inst_api_medians[col]))
                df_fused[col] = df_fused[col].fillna(df_fused["Institution_Name"].map(mapping))

        # Add derived composite features
        # Notice Urgency Days: Deadline - Issue
        issue_dt = pd.to_datetime(df_fused["Issue_Date"])
        deadline_dt = pd.to_datetime(df_fused["Deadline_Date"])
        df_fused["Notice_Duration_Days"] = (deadline_dt - issue_dt).dt.days

        # Composite Outdoor Safety / Travel Advisory Index
        # Formula: Normalized Temp Impact + Normalized AQI Impact
        temp_norm = (df_fused["Temperature_Max_C"] - df_fused["Temperature_Max_C"].min()) / (df_fused["Temperature_Max_C"].max() - df_fused["Temperature_Max_C"].min() + 1e-5)
        aqi_norm = (df_fused["Air_Quality_Index_US_AQI"] - df_fused["Air_Quality_Index_US_AQI"].min()) / (df_fused["Air_Quality_Index_US_AQI"].max() - df_fused["Air_Quality_Index_US_AQI"].min() + 1e-5)
        df_fused["Campus_Travel_Advisory_Score"] = ((0.4 * temp_norm + 0.6 * aqi_norm) * 100).round(1)

        # ---------------------------------------------------------------------
        # 3. Fusion Validation Metrics
        # ---------------------------------------------------------------------
        validation_metrics = {
            "Original_Records_Count": len(df_orig),
            "API_Records_Count": len(df_api),
            "Fused_Records_Count": len(df_fused),
            "Original_Attributes_Count": len(df_orig.columns),
            "API_Attributes_Count": len(df_api.columns),
            "Fused_Attributes_Count": len(df_fused.columns),
            "Matching_Record_Keys": len(matching_pairs),
            "Unmatched_Record_Keys": len(unmatched_orig),
            "Duplicate_Original_IDs": int(df_orig["Notice_ID"].duplicated().sum()),
            "Records_Lost_During_Fusion": 0,
            "New_Attributes_Introduced": len(df_fused.columns) - len(df_orig.columns),
            "Missing_Values_Fused": int(df_fused.isnull().sum().sum())
        }

        # ---------------------------------------------------------------------
        # 4. Dataset Comparison Summary Table
        # ---------------------------------------------------------------------
        comparison_data = [
            {
                "Parameter": "Number of Records",
                "Original Dataset": len(df_orig),
                "API Dataset": len(df_api),
                "Fused Dataset": len(df_fused)
            },
            {
                "Parameter": "Number of Attributes",
                "Original Dataset": len(df_orig.columns),
                "API Dataset": len(df_api.columns),
                "Fused Dataset": len(df_fused.columns)
            },
            {
                "Parameter": "Unique Identifiers",
                "Original Dataset": df_orig["Notice_ID"].nunique(),
                "API Dataset": df_api["API_Record_ID"].nunique(),
                "Fused Dataset": df_fused["Notice_ID"].nunique()
            },
            {
                "Parameter": "Missing Values (Total Cells)",
                "Original Dataset": int(df_orig.isnull().sum().sum()),
                "API Dataset": int(df_api.isnull().sum().sum()),
                "Fused Dataset": int(df_fused.isnull().sum().sum())
            },
            {
                "Parameter": "Duplicate Records",
                "Original Dataset": int(df_orig.duplicated().sum()),
                "API Dataset": int(df_api.duplicated().sum()),
                "Fused Dataset": int(df_fused.duplicated().sum())
            }
        ]
        df_comparison = pd.DataFrame(comparison_data)

        return df_fused, validation_metrics, df_comparison


def run_fusion():
    engine = DataFusionEngine()
    df_fused, metrics, df_comp = engine.fuse_datasets()
    
    out_path = os.path.join("data", "fused_dataset.csv")
    df_fused.to_csv(out_path, index=False)
    
    print("\n" + "=" * 60)
    print("DATASET FUSION COMPLETED SUCCESSFULLY")
    print("=" * 60)
    print(f"Saved fused dataset to: {out_path}")
    print(f"Dimensions: {df_fused.shape[0]} rows × {df_fused.shape[1]} columns")
    print("\n--- Fusion Validation Metrics ---")
    for k, v in metrics.items():
        print(f"  • {k}: {v}")
        
    print("\n--- Dataset Comparison Summary Table ---")
    print(df_comp.to_string(index=False))
    return df_fused, metrics, df_comp


if __name__ == "__main__":
    run_fusion()
