"""
=============================================================================
Module: src/data_cleaning.py
Project: NoticeSenseAI
Description: Comprehensive data cleaning, standardization, type casting,
             missing value treatment, and outlier detection for original,
             API, and fused datasets.
=============================================================================
"""

import os
import sys
sys.path.insert(0, os.path.abspath("."))

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any


class DataCleaner:
    """
    Cleans, standardizes, and validates academic circular records and external API datasets.
    """

    def clean_original_dataset(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Cleans original academic notices dataset.
        """
        df_clean = df.copy()
        
        # 1. Strip whitespace from string columns
        for col in df_clean.select_dtypes(include=["object", "string"]).columns:
            df_clean[col] = df_clean[col].astype(str).str.strip()

        # 2. Standardize dates
        df_clean["Issue_Date"] = pd.to_datetime(df_clean["Issue_Date"], errors="coerce").dt.strftime("%Y-%m-%d")
        df_clean["Deadline_Date"] = pd.to_datetime(df_clean["Deadline_Date"], errors="coerce").dt.strftime("%Y-%m-%d")

        # 3. Numeric casting & validation
        df_clean["Fee_Amount_INR"] = pd.to_numeric(df_clean["Fee_Amount_INR"], errors="coerce").fillna(0).astype(int)

        # 4. Remove exact duplicates
        df_clean = df_clean.drop_duplicates(subset=["Notice_ID"])
        
        return df_clean

    def clean_api_dataset(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Cleans API-collected multi-source dataset.
        """
        df_clean = df.copy()

        # 1. Clean strings
        for col in df_clean.select_dtypes(include=["object", "string"]).columns:
            df_clean[col] = df_clean[col].astype(str).str.strip()

        # 2. Date normalization
        df_clean["Date"] = pd.to_datetime(df_clean["Date"], errors="coerce").dt.strftime("%Y-%m-%d")

        # 3. Numerical columns type-casting
        num_cols = [
            "Latitude", "Longitude", "Temperature_Max_C", "Temperature_Min_C",
            "Precipitation_mm", "Wind_Speed_Max_kmh", "PM2_5_ug_m3",
            "PM10_ug_m3", "Air_Quality_Index_US_AQI", "Country_Population"
        ]
        for col in num_cols:
            if col in df_clean.columns:
                df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")

        # 4. Missing value imputation with group medians
        for col in ["PM2_5_ug_m3", "PM10_ug_m3", "Air_Quality_Index_US_AQI"]:
            if col in df_clean.columns and df_clean[col].isnull().any():
                df_clean[col] = df_clean[col].fillna(df_clean[col].median())

        return df_clean

    @staticmethod
    def detect_outliers_iqr(series: pd.Series) -> Tuple[pd.Series, Dict[str, float]]:
        """
        Computes IQR bounds and flags outliers.
        """
        clean_s = series.dropna()
        q1 = clean_s.quantile(0.25)
        q3 = clean_s.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        is_outlier = (series < lower_bound) | (series > upper_bound)
        stats = {
            "Q1": round(float(q1), 2),
            "Q3": round(float(q3), 2),
            "IQR": round(float(iqr), 2),
            "Lower_Bound": round(float(lower_bound), 2),
            "Upper_Bound": round(float(upper_bound), 2),
            "Outlier_Count": int(is_outlier.sum())
        }
        return is_outlier, stats

    @staticmethod
    def detect_outliers_zscore(series: pd.Series, threshold: float = 3.0) -> Tuple[pd.Series, Dict[str, float]]:
        """
        Computes Z-scores and flags outliers beyond threshold standard deviations.
        """
        clean_s = series.dropna()
        mean = clean_s.mean()
        std = clean_s.std()
        if std == 0:
            z_scores = pd.Series(0, index=series.index)
        else:
            z_scores = (series - mean) / std
        is_outlier = z_scores.abs() > threshold
        stats = {
            "Mean": round(float(mean), 2),
            "Std": round(float(std), 2),
            "Threshold": threshold,
            "Outlier_Count": int(is_outlier.sum())
        }
        return is_outlier, stats


def clean_all_datasets():
    cleaner = DataCleaner()
    
    orig_path = os.path.join("data", "original_dataset.csv")
    api_path = os.path.join("data", "api_dataset.csv")
    
    if os.path.exists(orig_path):
        df_orig = pd.read_csv(orig_path)
        df_orig_clean = cleaner.clean_original_dataset(df_orig)
        df_orig_clean.to_csv(orig_path, index=False)
        print(f"[Cleaning] Original dataset cleaned successfully: {len(df_orig_clean)} records.")

    if os.path.exists(api_path):
        df_api = pd.read_csv(api_path)
        df_api_clean = cleaner.clean_api_dataset(df_api)
        df_api_clean.to_csv(api_path, index=False)
        print(f"[Cleaning] API dataset cleaned successfully: {len(df_api_clean)} records.")


if __name__ == "__main__":
    clean_all_datasets()
